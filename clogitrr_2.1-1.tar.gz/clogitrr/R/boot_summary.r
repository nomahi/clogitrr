boot_summary <- function(fit, boot_coef, eform = TRUE, digit = 3) {
  est <- scoef(fit, eform = eform, digit = digit)[, 1, drop = FALSE]
  ci  <- sumboot(boot_coef, eform = eform, digit = digit)
  out <- cbind(est, ci)
  colnames(out)[1] <- if (eform) "exp(coef)" else "coef"
  out
}
