# clogitrr 1.1-1 (2025-09-28)

- first version released on GitHub
