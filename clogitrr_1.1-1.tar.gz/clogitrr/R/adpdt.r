adpdt <- function(y, data=NULL){

  data <- data.frame(data)
  y1 <- data[, deparse(substitute(y))]
  w1 <- which(y1==1)

  dt1 <- data[w1,]
  dt1[, deparse(substitute(y))] <- 0
  edata <- rbind(data,dt1)
  
  return(edata)

}
