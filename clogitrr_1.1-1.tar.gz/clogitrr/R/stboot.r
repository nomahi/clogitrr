stboot <- function(strata, data=NULL){

	data <- data.frame(data)
	id <- data[, deparse(substitute(strata))]
	
	ID <- unique(id)
	n <- length(ID)

	bdata <- idb <- NULL
	
	for(i in 1:n){

		wi <- which(id==ID[i])
		ni <- length(wi)

		wb <- sample(wi,ni,replace=TRUE)
	
		bdata <- rbind(bdata,data[wb,])

	}
	
	return(bdata)

}
