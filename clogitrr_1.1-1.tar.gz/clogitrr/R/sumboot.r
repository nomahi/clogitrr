sumboot <- function(x, eform=FALSE, conf.level=0.95, digit=3){

	p1 <- dim(x)[2]

	c1 <- 0.5*(1 - conf.level)
	c2 <- 1 - 0.5*(1 - conf.level)

	cl <- cu <- P1 <- numeric(p1)

	for(i in 1:p1){

		cl[i] <- quantile(x[,i],c1)
		cu[i] <- quantile(x[,i],c2)
		P1[i] <- 2*(min(mean(x[,i]>0),1-mean(x[,i]>0)))
	
	}
	
	if(eform==FALSE){
	
		R1 <- data.frame(cl,cu,P1)
		R1 <- round(R1,digit)
		colnames(R1) <- c("CL","CU","Pr(>|z|)")
	
	}

	if(eform==TRUE){
	
		R1 <- data.frame(exp(cl),exp(cu),P1)
		R1 <- round(R1,digit)
		colnames(R1) <- c("exp(CL)","exp(CU)","Pr(>|z|)")
	
	}

	return(R1)

}
